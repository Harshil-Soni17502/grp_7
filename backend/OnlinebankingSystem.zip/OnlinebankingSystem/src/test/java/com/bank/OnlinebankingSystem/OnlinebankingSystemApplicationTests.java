package com.bank.OnlinebankingSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlinebankingSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
