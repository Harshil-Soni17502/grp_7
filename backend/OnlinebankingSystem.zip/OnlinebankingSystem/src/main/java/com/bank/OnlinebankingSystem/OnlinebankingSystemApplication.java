package com.bank.OnlinebankingSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlinebankingSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlinebankingSystemApplication.class, args);
	}

}
